void runtordyn(struct griddata& den1,struct geometry& geo,
     struct tordyn& tordata,struct tordyn& tordata2);
void runonesidetordyn(int iside,struct griddata& den1,struct geometry& geo,
     struct tordyn& tordata);
void copysidegeotoauto(struct geometry& geo,struct tordyn& tordata);

