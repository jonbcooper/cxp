void drawpdb(struct pdbfile& pdb1,struct screenvalue&  sc);
void drawresidue(struct pdbfile& pdb1,int is,int i,
       int iprev,int windowselect);
void allocatelev(struct pdbfile& pdb1); 
void drawmodel(struct geometry& geo,struct screenvalue&  sc,struct maiddatafile& maidfile,
      int& windowselect);
void printString(char *s);
void labelres(); /*assume only one segment*/


void drawrot(int restype,float rotpos[NATOMS][3],int side[AA][NBRN][NPTS]);
