void pdbpulldown(Widget menubar);
