struct griddata{ // All the variables connect with a specific map (denfile) - grid size
       // contour range, contour arrays, etc.
       // Each map has separate contour, etc.  because different grid dimensions
   char mapname[300]; // Name of the denfile
//   char corename[100]; // Name of the corefile
   float cell[7],cosal,cosbe,cosgam,singam,sinbe,sinal,cvy,cvz;
   float ximin[3],ximax[3]; //=amin[i]*delx[i];  used in mcv the minimum x[i] value
   float delx[3];
   float color[3];
   int na[3],amin[3],amax[3],griddim[3];
   int crange[3];
   signed char ***den;  // runs from  -128  to 127
   float conlevel;
   // Following arrays are used for contours -allocated at run time
   int contonoff,selectcontonoff;
   int **tri;
   int ntri;  //max number of triangle allowed
   signed char ****dengr;  // gradient of density
};   

#if 0
extern struct tordyn tordata;
extern struct maiddatafile maidfile;
extern struct pepfit fit[NFIT]; // defined in peptide.h, see trace.c++ for definitin
extern int fitnum[NFIT];// see trace.c++ for definition
extern struct spheredata sp[NSPHERES];
extern struct screenvalue  sc;
#endif
#define NDIM 15  // number of adjustable variable  in pfunc
#define phead struct geometry& geo,struct griddata& den1,int nvar,struct pepfit fit1,struct pepfit fit2,float origphi[3],float origpsi[3],float ipos[NAFIT][NAA][3],float fpos[NAFIT][NAA][3],int cafix,float zaxis[],float xaxis[],float pp[] 
#define pfunc geo,den1,nvar,fit1,fit2,origphi,origpsi,ipos,fpos,cafix,zaxis,xaxis,pp


void savefit();
void saveonefit(FILE *fp,struct pepfit fit[],int i,int inum);
void readfit(struct geometry& geo, const char fitfile[]);
void readrankfit(char rankedfile[],int *nrank, struct pepfit fits[],int ifirst);
void readset(char setfile[],struct pepset& fitset);
void  readonefit(FILE *fp,struct pepfit fit[],int irank0,int i);
void deletefit(int ifit); 
void freepepfit(struct pepfit& fit);
void tracepep(struct griddata& den1,
        struct geometry& geo,struct bonedata& bone1);
void tracepepbatch(struct griddata& den1,
        struct geometry& geo,struct bonedata& bone1);
float aveatom(struct griddata& den1,struct geometry& geo,int itype,
     int inum,float pos[NAFIT][NAA][3]);
float avepos(struct geometry& geo,struct griddata& den1,float pos[3]);
void avemidden(struct griddata& den1,struct geometry& geo,
       float pos[NAFIT][NAA][3],float *ave,float *avemid);
void aveden(struct griddata& den1,struct geometry& geo,
       float pos[NAFIT][NAA][3],float *ave,float *avecb2,float *aveco,
       int *nbad,int resbad[NAA]);
void avedengeooneside(struct griddata& den1,struct geometry& geo,
      float pos[NAFIT][NAA][3],int iside,float *aveden,int *nbad);
int cadel(struct geometry& geo);
int ca_caang3(struct geometry& geo);
void aveden0(struct griddata& den1,struct geometry& geo,
       float pos[NAFIT][NAA][3],float *ave);
void avedenfit0(struct griddata& den1,struct geometry& geo,
           struct pepfit fit,float *ave,float *frout);
void aventermden(int usecb,struct griddata& den1,struct geometry& geo,int ica,
       float pos[NAFIT][NAA][3],float *ave,int *nbad);
void avectermden(int usecb,struct griddata& den1,struct geometry& geo,int ica,
       float pos[NAFIT][NAA][3],float *ave,int *nbad);
void avedenreg(struct griddata& den1,struct geometry& geo,
       float pos[NAFIT][NAA][3],float *ave,float *avecb2,int *nbad,
       int rbeg,int rend);
void avedenregcb(struct griddata& den1,struct geometry& geo,
       float pos[NAFIT][NAA][3],float *ave,float *avecb2,
       int *nbad,int rbeg,int rend);
void avedenregcbside(struct griddata& den1,struct geometry& geo,
       float pos[NAFIT][NAA][3],float *ave,float *avecb2,
       float *nbad,int rbeg,int rend);
void sidenum(int deleteend,struct griddata& den1,struct geometry& geo);
void sidenum2(struct griddata& den1,struct geometry& geo);
void sidenumreg(int ibeg,int iend,struct griddata& den1,
       struct geometry& geo);
void sidenumregfit(int ibeg,int iend,struct griddata& den1,
       struct geometry& geo,struct pepfit& fit);
void cbdenreg(int ibeg,int iend,struct griddata& den1,
       struct geometry& geo);
void copypos(int iside[],int n0,int i0,int i1,float pos0[NAFIT][NAA][3],float pos1[NAFIT][NAA][3]);
void addcterm(struct geometry& geo,struct griddata& den1,int constrainttype);
void addnterm(struct geometry& geo,struct griddata& den1,int constrainttype);
void naddnterm(struct geometry& geo,struct griddata& den1,int constrainttype);
void copygeotofit(struct geometry& geo,struct pepfit& fit,int nii[]);
void copyregfittogeo(struct geometry& geo,struct pepfit& fit,
      int istart,int iend);
void copyreggeotofit(struct geometry& geo,struct pepfit& fit,int istart);
void copyreggeotofitnterm(struct geometry& geo,struct pepfit& fit,int iend);
void copyfittogeo(struct geometry& geo,struct pepfit& fit);
void copyfittofit(struct pepfit& fit1,struct pepfit& fit2);
void copyfittofit(struct pepfit& fit1,struct pepfit& fit2,
  int beg1,int end1);
void copyfpostopos(struct geometry& geo,int num,int norc);
void copypostofpos(struct geometry& geo,int num,int norc);
void copyavefpostopos(struct geometry& geo,int num);
void copy2fitstogeo(struct geometry& geo,struct pepfit& fitn,
             struct pepfit& fitc);
void addfittofit(struct pepfit fit1,struct pepfit fit2,
      struct pepfit& fittemp);
void copyreg2fitstogeo(struct geometry& geo,struct pepfit& fitn,
             struct pepfit& fitc,int *istart);
void setpts(struct griddata& den1,struct geometry& geo,int ***set,int setside);
void setoneside(int i,struct griddata& den1,struct geometry& geo,int ***set,
        int setside);
void setsidepts(struct griddata& den1,struct geometry& geo,int ***set,int setside);
void setendpts(struct griddata& den1,struct geometry& geo,int ***set);
void setfit(struct griddata& den1,struct geometry& geo,struct pepfit& fit,
             int ibeg,int iend,int val,int ***set,int sideonly);
void setendptsfit(struct griddata& den1,struct geometry& geo,
       struct pepfit& fit,int ***set);
void setonesidefit(int i,struct griddata& den1,struct geometry& geo,
      struct pepfit& fit,int ***set,int setside);
void setsideptsfit(struct griddata& den1,struct geometry& geo,
      struct pepfit& fit,int ***set,int setside);
void setptsfit(struct griddata& den1,struct geometry& geo,struct pepfit& fit,
       int ***set,int setside);
void bestcb1(struct griddata& den1,struct geometry& geo,
       float ipos[NAFIT][NAA][3],int icb,float *avecb2);
int checkboundary(struct griddata& den1,float pos[NAFIT][NAA][3],int atomnum,
    int resnum,float arange);
int checkresidue(int nc,struct geometry& geo,struct griddata& den1,
            int ***set,float lastden,int nbad,float phi,float psi,int rtype);
int checkatom(struct griddata& den1,struct geometry& geo,int ***set,
      float pos[3]);
void setatom(struct griddata& den1,struct geometry& geo,int ***set,
    float pos[3],int val);
void allocatefit(struct pepfit& fit,int nalloc);
void powellmin(float *finalden,phead,float (*func)(float p[],phead));
int checkangrange(struct geometry& geo,float phi,float psi,int rtype,
    float *phimin,float *phimax,float *psimin,float *psimax);
float siderot(float a1[3],float a2[3],float b1[3],float b2[3]);
float corot(float c1[3],float c2[3],float o1[3],float o2[3]);
float co_axisang(struct geometry& geo,int i);
void rotccb(struct geometry& geo,float pos[NAFIT][NAA][3],float fpos[NAFIT][NAA][3],
     int n0,float rotv[3],float orig[3],float ang);
void rotncb(struct geometry& geo,float pos[NAFIT][NAA][3],float fpos[NAFIT][NAA][3],
     int n0,float rotv[3],float orig[3],float ang);
int checksetcterm(struct griddata& den1,struct geometry& geo,int ***set,int ica);
void savefitcheckbone(struct griddata& den1,struct geometry& geo,
       struct bonedata& bone);
int checksphere(float pos[3],float sprad2[NSPHERES]);
void recallspheresbat(struct geometry& geo);
float helixca_caang(float pos0[3],float pos1[3],float pos2[3]);
void savebackupfit(char backupfile[]);

