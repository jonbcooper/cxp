void initialize(struct geometry& geo,int fitnum[NFIT],
       struct pepfit fit[NFIT],struct spheredata sp[NSPHERES],
       struct maiddatafile& maidfile,struct tordyn& tordata,
       struct tordyn& tordata2,struct bonedata bone[NMAPS],
       struct pepset fitset,struct rotomer rot[]);

void initgeo(struct geometry& geo);
// Next 2 were Moved from menu.c++
void writemaidfile(int inew,struct maiddatafile& maidfile,struct griddata map[],
         struct bonedata bone[]);
void readmap(char filename[],struct griddata& den1,
       struct maiddatafile& maidfile);
void setup(struct maiddatafile& maidfile,struct griddata map[],
          struct bonedata bone[],char name[]);
void saveden(struct griddata den1);
