/* tordyn.h
NOTE: The big arrays unit, uside and sidedata are allocateda at run time
   and there sie can be increased if needed
      They are allocated with the size tordata.maxaunits and tordata.maxsunits
   The smaller array arrays are preallocated with NUNIT, etc. and ar fixed.
      HOWEVER: tordata.maxaunits must be less than NUNIT1
   Thus, to save space, can initially set  tordata.maxaunits  to small value
     much smaller than NUNIT1 and then increase as needed.
*/
#define EXTERN extern  /*when read def.h make all EXTERN variables extern*/
#include "global.h"  // global variables  color functions  (external variable)
//#define NUNIT1 400 /* max * of 1 type units on one autotrace = Max. #of residues */
#define NUNIT1 300 /* max * of 1 type units on one autotrace = Max. #of residues */
#define NUNIT 2*NUNIT1 /* max # of 1 + 2 type units on one autotrace = (# of residues)/2 */
#define NSUNIT 5*NUNIT1  /* max # of sideunits on one autotrace*/

struct tordyn// Parameters and values used with torsion dynamics
{
   float delt;// time step in tordyn
   int adata[7];
   float amass[4];//assign 4 atoms (Ca, Cb, Co, N dimensionless mass = 1
   float vm,gclin,rfor,rfor2,rfor3,rforside,torconst,torconstside,torconstend,angconst,distconst;
   float fuseconst;
   int cbond[2][2];
   int natraces;  
   int maxaunits;
   int maxsunits;
   float ****unit,***uside,****unitv,***usidev;
   int ** sidedata;
   int cis[NUNIT1];  // = 0 if standard trans proline, = 1 for cis proline
   int ttype[NUNIT]; // the constraint type for type0 or I unit(e.g. helix, sheet, ..) for bond PRECEDING unit
   float yy[NUNIT][6],dq[NUNIT],qs[NSUNIT],phipsi[NUNIT];
   float yys[NSUNIT][6],chi[NSUNIT],dqs[NSUNIT];
   int nunit1,nunit2;
   float angforconst[NCONSTRAINTS];
   int angsign[NUNIT]; // the sign of the tortional force to constrain phi/psi
   int nprelim;  // the number of tordyn steps in tordynbat before start search for optimin fit
   int irepeat; // if = 1, then repeat tordyn in trace.c++ at lower temp
   int fixend;  // if =3 then add force to minimize distance between last residue in tordat and tordat2
   int fend; //Number of residue at end, used when minimize distance between last 
   int useboneconstr;  // =1 if use force to keep Ca (or N?) close to edited bones
   float bonefor;
   int testpt[5]; // Used to find dist of Ca from edited bones
   int  nmax; //(Used if useboneconstr = 1:  number of bone pts to move out to find closept for each residue added
   int nadd; //  = # of residues to to add at each step in extendfit()
   int usediamond; // if = 1, use diamond force
   float oldphipsi[NUNIT],oldchi[NSUNIT];  // Previous values = used for Verlet algorithm
   float cbfix[3];  // the position of the fixed Cb used in refining rotomers
   int useringang;  // NEW - 29jan01 - allow variable ringang
   float ringang[NUNIT1],oldringang[NUNIT1],omega[NUNIT1],ringlim;
};

void finddengrad(struct griddata& den1);
void findforden(struct griddata& den1,struct geometry& geo,float apos[3],float forden[3]);
void setupauto(struct geometry& geo,struct tordyn& tordata);
void tordyn(struct griddata& den1,struct geometry& geo,
     struct tordyn& tordata);
void tordynbat(int quitcond,struct griddata& den1,struct geometry& geo,
     struct tordyn& tordata,float *returnden,
     int *returnbad);
void findangsign(struct geometry& geo,struct tordyn& tordata);
void avedenoneside(struct griddata& den1,struct geometry& geo,
      struct tordyn& tordata,int iside,float *aveden,int *nbad); 
void avedensetoneside(struct griddata& den1,struct geometry& geo,
      struct tordyn& tordata,int iside,float *aveden,
      int *nbad,int *badset); 
void avestddevoneside(struct griddata& den1,struct geometry& geo,
      struct tordyn& tordata,int iside,float *aveden,
      int *nbad,int *badset,float *stddev); 
void detaildenoneside(struct griddata& den1,struct geometry& geo,
      struct tordyn& tordata,int ibeg,int iend,float *aveden,int *nbad,
      float *firstden,float *lastden,int *totside); 
void detaildenonesideset(struct griddata& den1,struct geometry& geo,
      struct tordyn& tordata,int ibeg,int iend,float *aveden,int *nbad,
      float *firstden,float *lastden,int *totside,int icheck); // check for bad contacts for i>=icheck
void ncopygeotoauto(struct geometry& geo,struct tordyn& tordata);
void copyautotogeo(struct geometry& geo,struct tordyn& tordata);
void copyonesidetogeo(struct geometry& geo,struct tordyn& tordata);
void allocatetordata(struct tordyn& tordata);
void deallocatetordata(struct tordyn& tordata);
