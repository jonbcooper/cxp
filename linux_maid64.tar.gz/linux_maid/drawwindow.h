/* wincallback.h  Routines for call backs in the draw windows */
#define EXTERN extern  /*when read def.h make all EXTERN variables extern*/
#define NRESWIND 200 // maximum # of residue in window for each pdb segment
#define NBONEWIN 1000  // maxiumu # of bone pts in bone window
#include "global.h"  // global variables  color functions  (external variable)

//One or other of following calls to STL is used by different C compilers
#if 0 // Use this for SGI CC and gnu g++ compiler
#include <vector.h>  
#endif
#if 1 // Use this for Portland pgCC and Compact Tru64 compilers 
#include <vector>  
#endif

void findbonewind();
void findpdbwind();

struct segres  //segment and residue number picked for each pdbflie
{
   int seg;
   int num;
};


struct pdbfile{ // data for each pdb file
    int start; //= 1 if first just starting (no lev file), 0 if lev file define
    int iset;  // = 0 if geo.set[][][] has not been set for this pdb, 1 if set
    char name[300];
    float ****mainch;//pos[x,y,z= mainch[segment][residue][atomtype][x,y,z]
    float *****sidech;
    int **windmod;
    char ***rname;
    char ***resnumch;
    int **gaps;
    int ***resdat;
    float **maincolor;
    float **sidecolor;
    float linethick;
    float ****subch;
    int **subdata;
    int sideonoff;
    int onoff; // = 0, off; = 1 on
    float xmin[3];
    float xmax[3];
    struct segres pickres[PDBLABEL]; //Max. allowed picks per pdb = 100, pickres[0].num = total picked
};

struct maiddatafile{
    int start; //= 1 if first just starting (draw cube)), 0  switch to pdb; -1 find center etc
    int nden;
    int npdb;
    char name[300];
    char spherefile[300];
    char fitfile[300];
    struct pdbfile pdb[10];
    char pdbsequence[300];
    char resqual[300]; // file name where resqual is written
    char nsym[300];  // file that contain n sym rot/tran operators
    char selenomet[300];  // file that contains list of selenomet positions
    char editbones[300],firstedit[300];
    float denscale;  // mult. Xplor den. by this factor before converting to character
    int nsphere;  // total number of spheres in sphrefile
};


// structures maxima and joint are used in core routines
struct maxima{
   int value; // den value of point
   int joinnum;
   int join[6]; // the joins it is connect to (up to 6 - 0,1,2,3,4,5
   int pos;  // the 1d position of point
};
struct joint{
   int value; // den value of point
   int maxima[2]; // the maxima it is connects 
   int pos;  // the 1d position of point
};
 
struct bonept{
   int pos; // 1 D pos of pt = its label
//   int den; // den value of pt  DO NOT NEED THIS - USE den[pos]
   int num; // number of connecting pts (maxiumu of MAXCON)
   int con[MAXCON]; // the label of the connect pts. (0,1,3 ...)
};
   
struct bonedata{ // all the variables associated with thin routines
   int num;  // Corresponds to ident. number thin = number of corresponding map fle
   char bonename[300]; // Name of the bonefile
   int iexist;  // = 0 if bonefile not yet created, = 1 if bonefile exists but not read, = 2 if bonefile read
   int pickbone; // bone num to highlight if sc.pickbone = 1
   float minden;  // minimum value of density  (in std. dev) that is possibly considered for thin
   int cmin[3],cmax[3]; // range over which thin is generated
   float mcolor[3],scolor[3]; // main and side color
   std::vector<struct bonept> ptv;
   int winpts[NBONEWIN];  // list of bone pts in window  (winpts[0] = tot num in window)
};




