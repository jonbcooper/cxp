#define NSYM 100  // max number of symmetery related un assigned fits
#define MAXIDENT  500 // Max number of residue i ident fit
#define IDENTFITS  20
#define MAXDEL 500
#define MAXIBAD  20 
#define IBADRES  100
void symfit(int iplus,int *ifind,int icheck,struct geometry& geo,struct griddata& den1,
     int afit,int isym[NSYM][2],int *nsym,float brot[NSYM][3][3],float btran[NSYM][3],
     int del[]);
void symfitass(int iplus,int *ifind,int icheck,struct geometry& geo,struct griddata& den1,
     int afit,int isym[NSYM][2],int *nsym,float brot[NSYM][3][3],
     float btran[NSYM][3],int del[]);
void symonefitass(int *ifind,struct geometry& geo,struct griddata& den1,
     int afit,int isym[NSYM][2],int *nsym,float rot[3][3],float tran[3],
     int del[],int ufit,float *minden);
void movefitaa(struct pepfit fit1,struct pepfit& fit2,float rotm[3][3],float tran[3],
    int maxside);
void savensym(char symfile[],int nsym,float rot[NSYM][3][3],
      float tran[NSYM][3] );
void applyrottran(struct geometry& geo,struct griddata& den1,int nsym,
             float brot[NSYM][3][3],float btran[NSYM][3],int del[MAXDEL]);
void  refinerottran(struct geometry& geo,struct griddata& den1,
        float brot[3][3],float btran[3],int maxside,float rotm[3][3],
        float tran[3],int ifit,float minden,float *finalden,float *frout);
void removeonebadfit(int ifit,int iselect,struct griddata& den1,
       struct geometry& geo,int del[MAXDEL],int origfit);
void readnsym(char symfile[],int *nsym,float rot[NSYM][3][3],
                float tran[NSYM][3] );
