/* control.h */

void rerefine(int icontrol,struct griddata& den1,struct geometry& geo);
void retrace(struct griddata& den1,struct geometry& geo,
         struct bonedata& bone1);
