void refine(struct geometry& geo,struct griddata& den1,
      int savlen,int *quittrace);
void cutco(struct geometry& geo,struct griddata& den1,
          int resbad[],int savlen,int *quittrace,int i,char angdist[20]); 
void cutside(struct geometry& geo,struct griddata& den1,
          int resbad[],int savlen,int *quittrace,int i,char angdist[20]); 
void cutca4(struct geometry& geo,struct griddata& den1,
          int resbad[],int savlen,int *quittrace,int i,char angdist[20]); 
void cutca3(struct geometry& geo,struct griddata& den1,
          int resbad[],int savlen,int *quittrace,int i,char angdist[20]); 
void cutoo(struct geometry& geo,struct griddata& den1,
          int resbad[],int savlen,int *quittrace,int i,char angdist[20]); 
void checkextendedfit(int icheckhelsh,struct geometry& geo,
   struct griddata& den1,int resbad[],int *quittrace);
void checkoneend(struct griddata& den1,struct geometry& geo,int *icut);
void checkoneenden(struct griddata& den1,struct geometry& geo,
    int *quittrace);
void checkoneendbranch(struct griddata& den1,struct geometry& geo,
        struct bonedata& bone1,int *quittrace);
void checkterm(struct griddata& den1,struct geometry& geo,
        struct bonedata& bone1,int *endvalue);
int testcaden(struct griddata& den1,struct geometry& geo);
void bonedistgeo(struct griddata& den1,struct geometry& geo,
         struct bonedata& bone,int *quittrace);
void bonedistgeo2(struct griddata& den1,struct geometry& geo,
         struct bonedata& bone,int *quittrace);
void closedist2(float pos1[3],float pos2[3],float capos[3],float *perpdist,
           float *linedist);
void avemaxbatch(struct griddata& den1,struct geometry& geo);
