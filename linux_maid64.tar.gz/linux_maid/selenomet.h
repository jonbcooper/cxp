#define NSYMOPS 20 /* max # of symmetry operators*/
#define MAXSEL  200 // Maximum number of selenomet positions

void findselpos(struct griddata& den1,char selenometfile[],int *intnum,
      int *nsel,float selpos[MAXSEL][3]);
