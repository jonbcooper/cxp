void multcbone(struct griddata& den1,struct pepfit fits[NSAVEFIT],
         struct geometry& geo,int *totadd,int iconnect,
         int *lastrank);
