void contourmap(struct griddata& den1,float selectpos[]); 
void marchcont(struct griddata& den1,int imin[],int imax[]);
void mcv(struct griddata& den1,float xi[3],float sx[3]);  /*convert from xi,xj (in fractional floating point)
	 to world co-ord, identical to cv but uses vectors*/
void xtoi(struct griddata& den1,float xx[3],int ijk[3]); //convert from world co-ord to interger i,j,k co-ord
void drawsurface(struct griddata den1); 
void equivsurf(struct griddata den1,int ie);
void readcubeclass(char classfile[100]);
