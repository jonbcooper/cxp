#define NCHAR 20   /*max number of characters in some arrays */
#define AA 23 /* maximum # of types of residues*enum atomnum */

#define NATOMS 100  /* maximum number of atom types in pdb file*/
#define NPTS 14 /* maximum # of points on a.a. side branch*/
#define NBRN 5 /* nbrn=4 is used to indicate change in side -- maximum # of side branhes per residue*/
//#define NST NSEG /*this must be at least 2 and >=NSEG, used so that NSEG can = 1*/
#define NGAPS 100 /* maximum # of gaps per pdb segment */
#define SUBBRN 25 /*maximum # of branches per substrate*/
#define SUBNPTS 20 /*maximum # of points on substrate branch*/
#define NROT 11  // Maxinum of rotomers for each residue
// In new version  - memory allocated at run time

enum atomnum /* modified so that 1 to 6 corresponds to
   1=ca,2=c,3=o;4=n,5=cb; 6=cb2 used in fit routines */
{
  ZER0,CA,C,O,N,CB,OG,CD,CD1,CD2,CE,CE1,CE2,CE3,CG,CG1,CH1,CH2,CG2,CZ,CZ1,CZ2,CZ3,C1,C2,C3,
  C4,C5,C6,ND1,ND2,NE,NE1,NE2,NH1,NH2,NZ,OD,OD1,OD2,OE1,OE2,OG1,OG2,OH,
  O11,O12,O3,O41,O42,O61,O62,SD,SG,OHH 
};

enum residuenum
/*
New  Insert ZERORES IN BEGinning, this insures no residue with 0 value
 Important:list in order: amino acids, substrates, water
 3AA and 4AA are artificial residues with straigh 3 and 4 atoms
 3AA is made by droping one C from Leu, and 4 by dropping an O from GLU
*/
{
  ZERORES,ALA,ARG,ASN,ASP,CYS,GLU,GLN,GLY,HIS,ILE,LEU,LYS,MET,PHE,PRO,SER,THR,
    TRP,TYR,VAL,AA3,AA4,CIT,SOL
};



void rereadpdb(struct pdbfile& pdb1);
void pdbtolev(int countseg,int countwater,int countres,int countsubst,float ****subch,char ***rname,
    int **subdata,char ***resnumch,float ****mainch,
    float *****sidech,int **gaps,int ***resdat,
    float **maincolor,float **sidecolor,
       char pdbfile[],float xmin[3],float xmax[3]);
void findpdbdimensions(char pdbfile[],int *nseg,int nres[],int *nsubst,
        int  *nwater);
void data_side(int side[AA][NBRN][NPTS],int brdraw[AA][NBRN]);
void assignresnum(char nres[],char nm[],int *resn);
void assignatomnum(char nres[],char resname[],char na[],int *atomn);
void checkatomname(int side[AA][NBRN][NPTS],char nres[],int resname,int *atomnum);
void copyreglevtofit(struct pepfit& fit,struct pdbfile& pdb,
      int segn,int lev0,int lev1);
void copyonefittolev(struct pepfit& fit,struct pdbfile& pdb,
      int fitres,int segn,int resn);
void copypostofit(struct pepfit& fit,float pos[OHH+2][3],int ires,int rnum,
         char  segchar[]);
void copylevtofit(struct pepfit& fit,struct pdbfile& pdb,char pdbfile[]);
void writelevtopdb(struct pdbfile& pdb,char pdbnew[]);

#if 0
// Following are used in assignseq.c++
struct rotomer{  
   float chiang[11][3]; // the set of chiangles (only 3 are needed) for each rotomer (up to max of 11)
   int rotnum; // the number of rotomers for this type
};

void setuprotomer(struct rotomer rot[]);
void buildrot(struct geometry& geo,struct pepfit fit,int resnum,int restype,float chiang[3],
         float rotpos[NATOMS][3]);
#if 0
void copyonerottofit(float rotpos[NATOMS][3],struct pepfit& fit,int fitloc,
     int rottype);// copy rotomer side chain to fit
#endif
#endif
