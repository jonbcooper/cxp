void combine(struct griddata& den1,struct geometry& geo,char combinefile[]);
void expand(struct griddata& den1,struct geometry& geo,char expandfile[]);
void assignseqment(struct griddata& den1,struct geometry& geo,char callfile[]);
void rotatepdb(struct pdbfile& pdb,char pdbnew[]);
void removebadfits(int iselect,struct griddata& den1,struct geometry& geo);
