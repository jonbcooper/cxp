void writefittopdb(struct griddata& den1,struct geometry& geo,struct pepfit fit[],int fitnum[],
            char fitpdbfile[]);
void writepdbtofit(struct geometry& geo,struct pepfit fit[NFIT],int fitnum[NFIT],
            char fitpdbfile[]);
void writefittopdbassign(struct griddata& den1,struct geometry& geo,
            struct pepfit fit[NFIT],int fitnum[NFIT],
            char fitpdbfile[]);
void writefittopdbgen(struct griddata& den1,struct geometry& geo,
            struct pepfit fit[NFIT],int fitnum[NFIT],
            char fitpdbfile[]);
