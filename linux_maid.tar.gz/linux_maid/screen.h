//  Global variables that use screen functions
//  global.c++ call this file and sets EXTERN to blank
//  All other files call it and set EXTERN to extern
#include <GL/glx.h>
#include "Xgl.h"
#include "global.h"
// Following are used for contour routines
#define NTRI 20000 //maximum # of triangles in contour
  // 20,000 is OK for 20 Angstrom radius at res = 3 (del = 1.0)
  // Scale appropriately for different value of del

EXTERN GLfloat whitev[3];
EXTERN GLfloat blackv[3];
EXTERN GLfloat redv[3];
EXTERN GLfloat greenv[3];
EXTERN GLfloat bluev[3];
EXTERN GLfloat lightbluev[3];
EXTERN GLfloat yellowv[3];
EXTERN GLfloat pinkv[3];
EXTERN GLfloat cyanv[3];
EXTERN GLfloat magentav[3];
EXTERN GLfloat mycolor1[3];
EXTERN GLfloat mycolor2[3];
EXTERN GLfloat mycolor3[3];
EXTERN GLfloat mycolor4[3];
EXTERN GLfloat mycolor5[3];
EXTERN GLfloat mycolor6[3];
EXTERN GLfloat backcolv[3];
EXTERN GLfloat writecolv[3];
EXTERN GLfloat pdb1maincol[3];
EXTERN GLfloat pdb1sidecol[3];
void defglob();
void mycolor(GLfloat vec[3]); 


void errormessage(Widget widget, char errortext[]);

struct st { // define global variable for callbacks in menu items
   Widget w[5]; // maxinum of 5 entries
   int num;// num of entries in dialog box
};


struct screenvalue  // values needed for complete description of window view 
{
     GLsizei winwidth,winheight;
     GLfloat trans[3],rot[3],mag;
     GLfloat cubecol[3],spherecol[3];
     Boolean direct;
     void * func;  // pointer to function you want to draw
     Widget drawwind1,drawwind2;
     Widget     pullright[MAXPDB];// pdb pull right window - turn sensitive on/off
     Widget     mappullright[NMAPS];//map pull right window - turn sensitive on/off
     GLXContext      glxcontext;
     XtWorkProcId run_wpid;
     float cmmaxh,cmeyedist,degfovy,cmeyesep,centerpos[3],cut;
     int windowselect,pdbwindow,corewindow; // Indicates if selected limiting display window, 
     XtAppContext appctx;
     int printres,centerres;  // = 1 if want to print/center pdb labels, = -1 if not
     int centercore; // =1 if want to 
     int drawcontour;
     float pdbradius2,boneradius2;// square of pdb,bone radius -Set for all pdb's
     float coreradius2; // square of core radius -Set for all cores's 
     float contourradius,conlevel;//default linear contour radius and contourlevel
                  // Also set default pdb and core raduis = 1.5*contourradius
                      // contour radius and level can then be set separately for each map
     int isphere;// current sphere that is active and total number
     int drawspheres,addsphere,movesphere,selectsphere,deletesphere; 
     int drawfit,pickfit,drawgeo,drawrot;
     int draweditbones;
     int pickbone;
     int refinepdbside,savepdb; // Used in pdbmenu
     int drawgrid;  // New 6feb01 - draw map grid or boundary on screen
};

void resize(Widget w, XtPointer client_data, XtPointer call); 
void input(Widget w, XtPointer client_data, XtPointer call); 
void input2(Widget w, XtPointer client_data, XtPointer call); 
void expose(Widget w, XtPointer client_data, XtPointer call);
Boolean draw_screen(XtPointer clientdtata);
void printString(char *s);
void makeRasterFont(Display *dpy);
void drawx(float xlen,float pos[3]);
void drawline(float fvec[3],float fvec2[3]);
void drawpeptide(struct geometry& geo);
void drawfit(struct geometry& geo,struct pepfit fit[NFIT],
        int fitnum[NFIT]);
void drawbone(struct griddata& den1,struct bonedata& bone1,int windowselect);
void definepdbcolor(int nseg,float **maincolor,float **sidecolor);
void savepick(struct geometry& geo);
void spherepulldown(Widget menubar);
void drawspheres();


