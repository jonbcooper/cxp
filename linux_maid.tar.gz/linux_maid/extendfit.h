#define MAXSTRONG 100
#define MAXROT 46 // Number of rotations to find best phi/psi angle
#define MAXADD 4 // max. number residues added each step

void extendfit(struct pepset& fitset,struct griddata& den1,
       struct geometry& geo);
void extendandfuse(struct pepset& fitset,struct griddata& den1,
       struct geometry& geo,float fusedata[]);
void extendandfusebatch(struct pepset& fitset,struct griddata& den1,
       struct geometry& geo);
void batchextend(struct griddata& den1,struct geometry& geo,int *foundedit,
              int *ibestden);
void rotonca(struct geometry& geo,float pos[NAFIT][NAA][3],float fpos[NAFIT][NAA][3],
      int n0,float rotv[3],float orig[3],float ang); //rotate o,n,and ca about rotv
void nrotcoca(struct geometry& geo,float pos[NAFIT][NAA][3],float fpos[NAFIT][NAA][3],
      int n0,float rotv[3],float orig[3],float ang); //nterm rotate o,Cand ca about rotv
void aveoncaden(struct griddata& den1,struct geometry& geo,
       int n0,float fpos[NAFIT][NAA][3],float *aveden);
void avecocaden(struct griddata& den1,struct geometry& geo,
       int n0,float fpos[NAFIT][NAA][3],float *aveden);
void findstrongpsi(struct griddata& den1,struct geometry& geo,float fpos[NAFIT][NAA][3],
        float delrot,int nrot,float phi0,int n0,
        int *nstrong2,float psimax[],float dstrong2[]);
void findstrongphipsicterm(struct geometry& geo,struct griddata& den1,
    float maxphipsi[MAXSTRONG][2],float maxden[MAXSTRONG],int *nstrong);
void findstrongphipsinterm(struct geometry& geo,struct griddata& den1,
    float maxphipsi[MAXSTRONG][2],float maxden[MAXSTRONG],int *nstrong);
void checkend(struct griddata& den1,struct geometry& geo,struct bonedata& bone1,
        int savlen,int startfitnum);
int checkendden(struct griddata& den1,struct geometry& geo,struct bonedata& bone1,
    float pos[NAFIT][NAA][3],int ifit);
void checkendbranch(struct griddata& den1,struct geometry& geo,
        struct bonedata& bone1,int startfitnum);
void bonedist(struct griddata& den1,struct geometry& geo,struct bonedata& bone);
void checkoverlap(struct geometry& geo,struct pepfit& fit1,
               struct pepfit& fit2,int *nlap,float *maxdist);
void callbatchextend(struct griddata& den1,
          struct geometry& geo,int *foundedit,int *ibestden);
void linedist(float pos1[3],float pos2[3],float capos[3],float *dist,
           float pos[3],int *idist);
void maincadist(struct geometry& geo,float capos[3],int imain,int pt0,int nmax,
    int mpt[],float* mdist,float pos[3],float *bdist); 
void maxfitdistgeo(struct geometry& geo,int *nlim);
void avedenregnadd(struct griddata& den1,struct geometry& geo,
       float pos[NAFIT][NAA][3],float *ave,float *avecb2,
       int *nbad,int rbeg,int rend,float nave[],int ocount);
void saverankfit(char rankedfile[],int nrank,struct pepfit fits[]);
void extendall(struct pepset& fitset,struct griddata& den1,
       struct geometry& geo);
void testgap(struct griddata& den1,struct geometry& geo);
void fuseextfit(struct griddata& den1,struct geometry& geo,int nlap,
    struct pepfit fitext,struct pepfit fitmet,int metend);
void fuseextfit2(struct griddata& den1,struct geometry& geo,int nlap,
    struct pepfit fitext,struct pepfit fitmet,int metend);
void fusedist(struct pepfit& fit1,struct pepfit& fit2,
       float *maxdist,float *mindist);
void fuseextfit3(struct griddata& den1,struct geometry& geo,
    struct pepfit fitext,struct pepfit fitmet,struct pepfit& newfit);
void batchextendcomb(struct griddata& den1,
          struct geometry& geo,int icon,int *foundcon);
