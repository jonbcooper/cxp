//cube.h  Simple cube drawing for test case

#include <GL/glu.h>
#define EXTERN extern  /*when read def.h make all EXTERN variables extern*/
#include "global.h"  // global variables  color functions  (external variable)

void drawcube(); // Routine that draws a solid cube inside a line cube
void sidecube(void);  /* make a square translated 0.5 in the z direction */
void cube(void);  /* make a cube out of 4 squares */
void translatecube(float tr[]);
void copyright(); 
