void findbone(struct griddata& den1,struct bonedata& bone1);
void readbonefile(struct bonedata& bone1);
void writebonefile(struct griddata& den1,struct bonedata& bone1);
void readbinarymap(struct griddata& den1);
void initializemap(struct griddata& den1);
void writebonetopdb(struct griddata& den1,struct geometry& geo,
      struct bonedata& bone1);
