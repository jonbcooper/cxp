void combine(struct griddata& den1,struct geometry& geo, const char combinefile[]);
void expand(struct griddata& den1,struct geometry& geo, const char expandfile[]);
void assignseqment(struct griddata& den1,struct geometry& geo, const char callfile[]);
void rotatepdb(struct pdbfile& pdb, const char pdbnew[]);
void removebadfits(int iselect,struct griddata& den1,struct geometry& geo);
