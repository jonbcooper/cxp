// Following are used in assignseq.c++
struct rotomer{  
   float chiang[11][3]; // the set of chiangles (only 3 are needed) for each rotomer (up to max of 11)
   int rotnum; // the number of rotomers for this type
};

void setuprotomer(struct rotomer rot[]);
void buildrot(struct geometry& geo,float n[3],float ca[3],float cb[3],
         int restype,float chiang[3],float rotpos[NATOMS][3]);
void buildrotring(struct geometry& geo,float n[3],float ca[3],float cb[3],
         int restype,float chiang[3],float ringang,float rotpos[NATOMS][3]);
void copyonerottofit(float rotpos[NATOMS][3],struct pepfit& fit,int fitloc,
     int rottype);// copy rotomer side chain to fit
void copyonerottogeo(float rotpos[NATOMS][3],struct geometry& geo,
       int geoloc,int rottype);// copy rotomer side chain to geo
void assignsequence(struct griddata& den1,struct geometry& geo,
       struct rotomer rot[]);
void rankaa(char resqual[]);
void copyrotsavtogeo(struct geometry& geo,int resn,float rotsav[NAA][3]);
void copygeotorotsav(struct geometry& geo,int resn,float rotsav[NAA][3]);
void buildseq(struct griddata& den1,struct geometry& geo,struct rotomer rot[]);
void buildandrefineseq(struct griddata& den1,struct geometry& geo,
         struct rotomer rot[],int ifit);
void testseq(struct griddata& den1,struct geometry& geo,struct rotomer rot[]);
void addoneletter(char nm[1],int *resn);
void removefit(struct pepfit fit[],int ifit);
void removenfits(struct pepfit fit[],int del[]);
void removenunordfits(struct pepfit fit[],int del[]);
void refineonepdbside(int writetofile,struct griddata& den1,
     struct geometry& geo,struct rotomer rot[],struct pdbfile& pdb,
     int segn,int resn);
void refineallpdbside(struct griddata& den1,struct geometry& geo,
     struct rotomer rot[],struct pdbfile& pdb);
void connectnum(struct geometry& geo,struct griddata& den1,
         int fitext,int fitmet,int fit3,int connum[],int ranki[],
         int ranki2[],int ranki3[],float rankf[],int ibestden,
         int cnum1,int cnum2,int nterm);
void connectnumass(struct geometry& geo,struct griddata& den1,
         int fitext,int fitmet,int connum[],int ranki[],
         int ranki2[],int ranki3[],float rankf[],int ibestden,
         int cnum1,int nterm);
void bestrotpow(int useset,int movecb,struct griddata& den1,struct geometry& geo,float *aveden,int *nbad,
        float pp[]);
void initsetptsfit(struct griddata& den1,struct geometry& geo);
void refineonerot(int useset,struct griddata& den1,struct geometry& geo,
          struct rotomer rot[],int ifit,int resn,int rottype,
          float *bestqual,int *bestnbad,int *bestbadset,int *bestrotn);
void refineonerotgeo(int useset,struct griddata& den1,struct geometry& geo,
          struct rotomer rot[],int resn,int rottype,
          float *bestqual,int *bestnbad,int *bestbadset,int *bestrotn);
void lowerconnectnum(struct geometry& geo,int *cnum);
void lowerconnectnumca(struct geometry& geo,int ibestden,int *cnum,
       int *maxngap);
void assignone(struct geometry& geo,struct griddata& den1,int iexclude,int *nassign);
void findside_maindistfit(struct pepfit& fit,int ires,float *mindist);
void testseqbatch(struct griddata& den1,struct geometry& geo);

