void fuse_ok_pushed(Widget w,XtPointer  client_data,
       XtPointer  call_data);
void fitpulldown(Widget menubar);
void buildpulldown(Widget menubar);
