//Global variables-  
//  global.c++ call this file and sets EXTERN to blank
//  All other files call it and set EXTERN to extern
//#define EXTERN  /* this sets EXTERN to blank, reads as not external*/ 

#include  <assert.h>
#include <stdlib.h>
#include <stdio.h>
//#include <iostream.h>
//#include <iomanip.h>
#include <time.h>
#include <math.h>
#define PI 3.141592653589763
#define DEGTORAD PI/180.0
#define MAXCHAR 127 // signed char runs from -128 to +127
#define MAXPDB 10
#define PDBLABEL 300
#define MAXCON 5  // maximum allowed connections to each bone point
#define NMAPS 7  // maximum number of allowed map files with associated contours, etc.
//#define NAFIT 60 /* max. # of amino acids used to fit mainchain*/
//#define NAFIT 200 /* max. # of amino acids used to fit mainchain*/
#define NAFIT 260 /* max. # of amino acids used to fit mainchain*/
//#define NAFIT 120 /* max. # of amino acids used to fit mainchain*/
#define NFIT 600 //26mar01 - increase from 200 to 600-  Max number of save geo peptide fits( must  = (about) number of fits * NSAVEFIT
#define NSAVEFIT 10 //  Number of saved ranked fits for each fit that is extended
//#define NAA 10 /*# of atoms in one amino acid = 1,2,,,NAA-1 */
#define NAA 20 // Must be large enough to acount for all the atoms in tryptophane
#define NSPHERES 10 // max number of sphere regions
#define NCONSTRAINTS 12 /* # of phi/psi constraints, 0=none,1=helix,2 = sheet,3-7 = beta turn, 8,9 special Proline regions*/
#define MAXRANK 30  // Max. number of ranking in call to rankqual()
// Following are used for contour routines
#define NTRI 20000 //maximum # of triangles in contour
  // 20,000 is OK for 20 Angstrom radius at res = 3 (del = 1.0)
  // Scale appropriately for different value of del
