void initializescreen(struct screenvalue& sc,struct geometry& geo);
