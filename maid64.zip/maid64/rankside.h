#define MAXNF 90
void rankseq(struct geometry& geo,char resqual[]);
int readsequence(struct geometry& geo,char pdbsequence[]);
void setupclass(int small[],int mid[],int big[],int ring[],int mclass[]);
void findconnectnum(struct geometry& geo,int *cnum);
void readresqual(char resqual[],int nfits[]);
void findqual(struct geometry& geo,int ifit,int seq0,float *tvalue);
void assignval1();
void freefitqual(struct pepfit& fit);


