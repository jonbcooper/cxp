
#define MAXMAIN 150 // maximum number of main chain
#define MAXSIDE 20 // Maximum  of side branchs on any one main chains
#define MAXSIDEPTS 30 // Maximum number of point on side branch (0,1,2,3,..5) where 0 = start point on main chain
#define MAXMAINPTS 100 // Maximum number of point on main branch (0,1,2,3,..5) where 0 = start point on main chain
#define MAXPATH 3 // maximum number of repeats of a  main chain on a connect path
#define MAINONEPTS 200 //maximum number of pts in the the final main when convered to to one main
struct sidebone // data for one edited maintrace
{
   int num; // total num of side pts  - 0, 1,2,... num (0 = start pos on mainchain) on this branch
   int ipos[MAXSIDEPTS]; // the bone number
   float pos[MAXSIDEPTS][3]; // real space poositon ith pt 
   int mnum; // the the number of the mainpoint that side starts on
   int ctype[3]; //  ctype[0] = 0 if no connections, =1 if con. to other mains, ctype[1,2] = main chain num and main pt it connects to
};

struct mainpoint // data for each main positon
{
   float pos[3]; // real space poositon ith pt 
   int num; // the bone point number - NOTE - this may be from either 1.4 or 0.8 boes
   int stype; // = 0 if no side brance at this point; or = side br. #
   int mtype;  // = 0 if no new main chain stars at this point; or = main ch. #  
   int ctype[4]; // ctype[0] = 0 if no connections, =1 if con. to other mains, 
                 // ctype[1,2,3] = main chain num and main pt it connects to,and side num
};   

struct mainbone // data for one edited maintrace
{
   int num; // num of main pts  - 0, 1,2,... num-1 (0 = start pos) on this main
   int startnum;  //  num. of main points from initial point of start point of this main
   int startmain; // The main bone that that this main bone starts from
   int mainnum; // The main point num on the that this main starts from
   int nside; // number of side chain  1,2, on this main chain
   int metend; // if >0 indicates this is main path to fitnum = metend
   int extpos; // the point num where current extension is occuring
   int zeronum; // the beginning pt in main - default = 0; but if cut front, then set new value
   struct mainpoint mainpt[MAXMAINPTS];
   struct sidebone side[MAXSIDE];
};

struct mainonebone // same as main bone but no sides
{
   int num; // num of main pts  - 0, 1,2,... num-1 (0 = start pos) on this main
   int startnum;  //  num. of main points from initial point of start point of this main
   int startmain; // The main bone that that this main bone starts from
   int mainnum; // The main point num on the that this main starts from
   int nside; // number of side chain  1,2, on this main chain
   int metend; // if >0 indicates this is main path to fitnum = metend
   int extpos; // the point num where current extension is occuring
   int zeronum; // the beginning pt in main - default = 0; but if cut front, then set new value
   struct mainpoint mainpt[MAINONEPTS];
};

struct extbones  // All the data for edited bones used to extend one end of a given fit
{
    int nmain; // # of main traces
    float stpos[3];  // world coordinate of start pos 
    struct mainbone main[MAXMAIN]; // MAXMAIN = max. # of main points 
    struct mainonebone mainone; // same as main bone but no sides
    int sidelim; // If number of side pts > sidelim, then assume it is a main branch
    int numlim; // Maximum number of bone pts from origin
    float distlim;
    int length;  // the total length of the edited mains that meet another fit
    float mecolor[3],secolor[3]; // main and side color
    int metend; // indicates met end of another fit with fitnum = metend
    int ifit;  // the current fit number that is being bones are being extended at
    int usenfits;  // Number of unassigned connected that must be linked to assigne seq. value};  
    int metmain[MAXMAIN]; // New 3nov00 - the mains on path to metend
};

void editbones(struct griddata& den1,float pos1[3],float pos2[3],
      struct geometry& geo,struct bonedata& bone1);
void checkifbranch(int checknear,struct griddata& den1,struct geometry& geo,
            struct bonedata& bone1,float pos1[3],float pos2[3],int *ibranch);
void checksidebranch(int checknear,struct griddata& den1,struct geometry& geo,
            struct bonedata& bone1,float pos1[3],float pos2[3],int *ibranch);
void checkobranch(int checknear,struct griddata& den1,struct geometry& geo,
            struct bonedata& bone1,float posc[3],float posca[3],
            float poso[3],int *ibranch);
void checkifbranchrec(int checknear,struct griddata& den1,struct geometry& geo,
            struct bonedata& bone1,float pos1[3],float pos2[3],
            int *ibranch,int pt[]);
void checkside_ca_branch(int checknear,struct griddata& den1,struct geometry& geo,
            struct bonedata& bone1,float posca1[3],float posca2[3],
           float poscb[3],int *ibranch);
void nearestbonept(struct griddata& den1,float pos[3],struct geometry& geo,struct bonedata& bone,
    int *nearnum,float *neardist);
void readeditbones();
void copyeditbones(struct extbones& ext1,struct extbones& ext2);
void copyoneeditbones(struct mainonebone& mainone1,struct mainonebone& mainone2);
void saveeditbones(const char editbone[],int testmetend);
void readeditbones(const char editbone[]);
void starttestconnect(struct bonedata& bone1,int pt1,int pt2,int maxdist,
        int *condist);
int connected(struct griddata& den1,struct geometry& geo,
            struct bonedata& bone1,int near1,int near2,
            float pos1[3],float pos2[3]);

