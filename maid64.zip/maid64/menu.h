#include "Xgl.h"
void  file_new_dialog(Widget w);
void close_dialog(Widget w,XtPointer  client_data,XtPointer  call_data);
void activate_cb(Widget w,XtPointer  client_data,XtPointer  call_data);
void new_ok_pushed(Widget w,XtPointer  client_data,XtPointer  call_data);
void old_ok_pushed(Widget w,XtPointer  client_data,XtPointer  call_data);
void clear_pushed(Widget w,XtPointer  client_data,XtPointer  call_data);
void help(Widget w,XtPointer  client_data,XtPointer  call_data);
void change_color(Widget widget,XtPointer  client_data,XtPointer  call_data);
void load_pixmap(Widget dialog,XtPointer  client_data,XtPointer  call_data);
void file_cb(Widget widget,XtPointer  client_data,XtPointer  call_data);
void help_cb(Widget widget,XtPointer  client_data,XtPointer  call_data);
void filepulldown(Widget menubar);
void itoa(int ii,char ch[]);
void activate_cb(Widget text_w,XtPointer  client_data,XtPointer  call_data);
             /* user pressed Return in this widget */
       /* dialog passed as client data */
struct  ActionAreaItem{
    char *label;
    void (*XtCallbackProc)(Widget w,XtPointer  client_data,XtPointer  call_data);
    XtPointer data;
};
void close_dialog(Widget w,XtPointer  client_data,XtPointer  call_data);
void clear_pushed(Widget w,XtPointer  client_data,XtPointer  call_data);
void  CreateActionArea(Widget dialog,ActionAreaItem * actions,int num_actions);
void errormessage(Widget widget, char errortext[]);
#if 0 // Moved to  initialize.h
void writemaidfile(int inew,struct maiddatafile& maidfile,struct griddata map[],
         struct bonedata bone[]);
#endif
void readmaidfile(struct maiddatafile& maidfile,struct griddata map[],
       struct bonedata bone[]);



