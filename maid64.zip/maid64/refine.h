// refine.h

void scaleden(struct griddata& den1,struct geometry& geo,float *rr);
void scaleden0(struct griddata& den1,struct geometry& geo);
void diamondfor(struct griddata& den1,struct geometry& geo,float atompos[3],
       float force[3]);
void setupdiamondforce(struct griddata& den1,struct geometry& geo,
      struct tordyn& tordata);

