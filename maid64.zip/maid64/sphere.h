
struct spheredata // values need for drawing, positioning, saving, etc. sphere
{
   int picksphere; // if = 1 then draw default sphere at picked bone point
   int movesphere; // if = 1 then move and adjust radius of sphere
   float radius; // default radius in Angstroms
   float cenpos[3];
};

